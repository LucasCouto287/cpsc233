public class SavingsAccount extends BankAccount{
  public static void main(String[] args) {

  }

  private double annualInterestRate = 0.05;
  private double minimumBalance;

  public double getAnnualInterestRate() {
    return this.annualInterestRate;
  }

  public void setAnnualInterestRate(double interestRate) {
    if(interestRate >= 0.0 && interestRate <= 1.0) {
      this.annualInterestRate = interestRate;
    }
  }

  public void withdraw(double amount) {
    if(amount <= balance && amount >= 0) {
      if(balance - amount >= minimumBalance) {
        balance -= amount;
      }
    }
  }

  public void depositMonthlyInterest() {
    super.deposit((annualInterestRate / 12.0) * super.balance);
  }

  public void setMinimumBalance(double minBalance) {
    this.minimumBalance = minBalance;
  }
}
